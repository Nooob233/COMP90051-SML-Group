# COMP90051-SML-Group

## Tables Description
This folder stores information processed from raw data. Please refer to the files' names with the suffix "processing" to see the process and method.